const mysql = require('mysql');
const conexion = mysql.createConnection({
    host: 'localhost',
    database: 'prueba',
    user: 'root',
    password: 'root',
    insecureAuth : true
});
conexion.connect((error)=>{
    if (error){
        console.error('el error de conexón es '+error);
        return
    }
    console.log('¡Conectado a la BD MySQL!');
})
module.exports = conexion;