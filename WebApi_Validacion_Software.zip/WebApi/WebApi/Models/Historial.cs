﻿namespace WebApi.Models
{
    public class Historial
    {
        public int? codigo { get; set; }    
        public DateTime? fecha { get; set; } 
        public int? monto { get; set; }
        public string? linea { get; set; }  
    }
}
