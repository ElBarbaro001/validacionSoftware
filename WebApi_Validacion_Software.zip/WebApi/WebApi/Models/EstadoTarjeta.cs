﻿namespace WebApi.Models
{
    public class EstadoTarjeta
    {
        public int? codigo { get; set; }
        public string? estado { get; set; }
    }
}
