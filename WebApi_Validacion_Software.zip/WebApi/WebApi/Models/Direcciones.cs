﻿namespace WebApi.Models
{
    public class Direcciones
    {
        public string? dir_casa { get; set; }
        public string? nombres { get; set; }
        public string? primer_apellido { get; set; }
        public string? segundo_apellido { get; set; }
        public string? genero { get; set; }
    }
}
