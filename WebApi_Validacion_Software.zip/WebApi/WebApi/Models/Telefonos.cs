﻿namespace WebApi.Models
{
    public class Telefonos
    {
        public string? nombres { get; set; }
        public string? primer_apellido { get; set; }
        public string? segundo_apellido { get; set; }
        public string? tfno_casa { get; set; }
        public string? tfno_trabajo { get; set; }
    }
}
