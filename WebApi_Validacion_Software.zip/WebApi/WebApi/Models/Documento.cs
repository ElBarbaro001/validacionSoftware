﻿namespace WebApi.Models
{
    public class Documento
    {
        public int? documento { get; set; }
    }
}
