using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebApi.Views
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
