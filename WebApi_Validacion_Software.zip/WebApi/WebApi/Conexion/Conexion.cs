﻿namespace WebApi.Conexion
{
    public class Conexion
    {
        public static string rutaConexion = "Data Source=DEV\\SQLEXPRESS;Initial Catalog=Cooperativa;Integrated Security=True";
    }
}